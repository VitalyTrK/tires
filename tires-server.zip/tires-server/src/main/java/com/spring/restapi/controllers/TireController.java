/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.restapi.controllers;

import com.spring.restapi.models.Count;
import com.spring.restapi.models.CustomerRef;
import com.spring.restapi.models.Tire;
import com.spring.restapi.services.tires.TiresService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @author vitaly .T
 */
@RestController
public class TireController {

    @Autowired
    private TiresService tiresService;

    @RequestMapping(method = RequestMethod.GET, value = "/tires")
    public ResponseEntity getAllTires() {
        return tiresService.getAllTires();
    }

    @RequestMapping(method = RequestMethod.GET, value = "/test")
    public String test() {
        return "hello Tal new API is coming...";
    }

    @RequestMapping(method = RequestMethod.POST, value = "/tires/add/garage/{id:.+}/{count}")
    public ResponseEntity addTire(@PathVariable String id, @PathVariable String count, @RequestBody Tire tire) {
        System.out.println("save tire to:" + id);
        CustomerRef customerRef = new CustomerRef(id, Integer.parseInt(count));
        return tiresService.addTire(customerRef, tire);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/tires/{id}")
    public ResponseEntity getTire(@PathVariable String id) {
        return tiresService.getTire(id);
    }


    @RequestMapping(method = RequestMethod.GET, value = "/garage/{id:.+}/tires")
    public ResponseEntity getTiresByGarage(@PathVariable String id) {
        return tiresService.getTiresByGarage(id);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/garage/{garageId:.+}/tires/{tireId}")
    public ResponseEntity deleteTireFromGarage(@PathVariable String garageId, @PathVariable String tireId) {
        return tiresService.deleteTireFromGarage(garageId, tireId);
    }


    @RequestMapping(method = RequestMethod.PUT, value = "/tires/{id}/update")
    public ResponseEntity updateTire(@PathVariable String id, @RequestBody Tire tire) {
        return tiresService.updateTire(id, tire);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/garage/{garageId:.+}/tires/{tireId}/count")
    public ResponseEntity setCountByGarage(@PathVariable String garageId, @PathVariable String tireId, @RequestBody Count count) {
        if (count != null) {
            return tiresService.setCountByGarage(garageId, tireId, count.getCount());
        }
        return ResponseEntity.badRequest().build();
    }

    @RequestMapping(method = RequestMethod.POST, value = "/garage/{garageId:.+}/tires/{tireId}/inc")
    public ResponseEntity incCountByGarage(@PathVariable String garageId, @PathVariable String tireId, @RequestBody Count count) {
        if (count != null) {
            return tiresService.incCountByGarage(garageId, tireId, count.getCount());
        }
        return ResponseEntity.badRequest().build();
    }
    @RequestMapping(method = RequestMethod.DELETE, value = "/tires/{id}")
    public ResponseEntity deleteTire(@PathVariable String id) {
        return tiresService.deleteTire(id);
    }
}