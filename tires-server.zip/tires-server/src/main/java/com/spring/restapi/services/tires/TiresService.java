package com.spring.restapi.services.tires;


import com.spring.restapi.models.CustomerRef;
import com.spring.restapi.models.Tire;
import com.spring.restapi.repositories.GarageRepositoryInterface;
import com.spring.restapi.repositories.TireRepositoryInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

@Component
public class TiresService {
    @Autowired
    private TireRepositoryInterface tireRepository;
    @Autowired
    private GarageRepositoryInterface garageRepositoryInterface;


    public ResponseEntity addTire(CustomerRef customerRef, Tire tire) {
        try {
            tire.setUpdateTime(System.currentTimeMillis());
            if (garageRepositoryInterface.findByEmail(customerRef.getGarageId()) != null) {
                if (tireRepository.findOne(tire.getBarcode()) != null) {
                    // already exists..assign to garage
                    if (tireRepository.addTireToGarage(customerRef, tire) > 0) {
                        return ResponseEntity.ok().build();
                    }
                } else {
                    if (tireRepository.save(tire) != null) {
                        if (tireRepository.addTireToGarage(customerRef, tire) > 0) {
                            return ResponseEntity.ok().build();
                        }
                    }
                }
            } else {
                System.err.println("Garage dont exists..");
            }
            return ResponseEntity.badRequest().build();
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
    }

    public ResponseEntity getTire(String tireId) {
        try {
            Tire tire = tireRepository.findOne(tireId);
            if (tire != null) {
                return new ResponseEntity<>(tire, HttpStatus.OK);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity getAllTires() {
        try {
            List<Tire> all = new ArrayList<>();
            Iterator<Tire> tire = tireRepository.findAll().iterator();
            while (tire.hasNext()) {
                Tire t = tire.next();
                all.add(t);
            }
            all.sort(Comparator.comparingLong(Tire::getUpdateTime).reversed());
            return new ResponseEntity<>(all, HttpStatus.OK);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
    }


    public ResponseEntity setCountByGarage(String garageId, String tireId, int count) {
        Tire tire = tireRepository.setCountByGarage(garageId, tireId, count);
        if (tire != null) {
            return new ResponseEntity<>(tire, HttpStatus.OK);
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity incCountByGarage(String garageId, String tireId, int incDec) {
        Tire tire = tireRepository.incCountByGarage(garageId, tireId, incDec);
        if (tire != null) {
            return new ResponseEntity<>(tire, HttpStatus.OK);
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity updateTire(String tireId, Tire tire) {
        try {
            Tire toUpdate = tireRepository.findOne(tireId);
            if (toUpdate != null) {
                toUpdate.setUpdateTime(System.currentTimeMillis());
                toUpdate.setDiameter(tire.getDiameter());
                toUpdate.setHeight(tire.getHeight());
                toUpdate.setImageURL(tire.getImageURL());
                toUpdate.setLoadIndex(tire.getLoadIndex());
                toUpdate.setManufacturer(tire.getManufacturer());
                toUpdate.setModel(tire.getModel());
                toUpdate.setPrice(tire.getPrice());
                toUpdate.setSpeedIndex(tire.getSpeedIndex());
                toUpdate.setWidth(tire.getWidth());

                Tire updated = tireRepository.save(toUpdate);
                if (updated != null) {
                    return new ResponseEntity<>(updated, HttpStatus.OK);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity deleteTire(String tireId) {
        try {
            if (tireId != null) {
                tireRepository.delete(tireId);
                return ResponseEntity.ok().build();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity deleteTireFromGarage(String garageId, String tireId) {
        try {
            if (tireId != null) {
                Tire t = tireRepository.deleteTireFromGarage(garageId, tireId);
                if (t != null) {
                    return ResponseEntity.ok().build();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity getTiresByGarage(String tireId) {
        try {
            if (tireId != null) {
                List<Tire> tires = tireRepository.getTiresByGarage(tireId);
                if (tires != null) {
                    return new ResponseEntity<>(tires, HttpStatus.OK);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }


}