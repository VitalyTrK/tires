package com.spring.restapi.repositories.custom;

import com.spring.restapi.models.CustomerRef;
import com.spring.restapi.models.Tire;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class TireRepositoryInterfaceImpl implements TireRepositoryInterfaceCustom {

    @Autowired
    protected MongoTemplate mongoTemplate;

    @Override
    public int addTireToGarage(CustomerRef customerRef, Tire tire) {
        System.out.println("trying update addTireToGarage....");
        // trying to find , if garage ID not exist in array need addToSet ,
        // if exists just inc count
        Query query = new Query();
        query.addCriteria(Criteria.where("barcode").is(tire.getBarcode())
                .and("accounts").elemMatch(Criteria.where("garageId").is(customerRef.getGarageId())));
        Tire t = mongoTemplate.findOne(query, Tire.class);
        if (t != null && t.getBarcode() != null) {
            // find -> so need to inc the count
            Tire updated = incCountByGarage(customerRef.getGarageId(), t.getBarcode(), customerRef.getCount());
            if (updated != null) {
                return 1;
            }
        }
        return mongoTemplate.updateFirst(
                Query.query(Criteria.where("barcode").is(tire.getBarcode())),
                new Update().addToSet("accounts", customerRef), Tire.class).getN();
    }

    @Override
    public List<Tire> getTiresByGarage(String garageId) {
        Query query = new Query();
        query.addCriteria(Criteria.where("accounts")
                .elemMatch(Criteria.where("garageId").is(garageId)));
        return mongoTemplate.find(query, Tire.class);
    }

    @Override
    public Tire deleteTireFromGarage(String garageId, String tireId) {
        Query query = new Query();
        query.addCriteria(Criteria.where("barcode").is(tireId)
                .and("accounts").elemMatch(Criteria.where("garageId").is(garageId)));

        Update update = new Update();
        update.pull("accounts", new Query().addCriteria(Criteria.where("garageId").is(garageId)));
        FindAndModifyOptions options = FindAndModifyOptions.options();
        options.returnNew(true);
        return mongoTemplate.findAndModify(query, update, options, Tire.class);
    }

    @Override
    public Tire setCountByGarage(String garageId, String tireId, int newCount) {
        Query query = new Query();
        query.addCriteria(Criteria.where("barcode").is(tireId)
                .and("accounts").elemMatch(Criteria.where("garageId").is(garageId)));

        Update update = new Update();
        update.set("accounts.$.count", newCount);
        update.set("accounts.$.updatedTime", System.currentTimeMillis());
        FindAndModifyOptions options = FindAndModifyOptions.options();
        options.returnNew(true);
        return mongoTemplate.findAndModify(query, update, options, Tire.class);
    }

    @Override
    public Tire incCountByGarage(String garageId, String tireId, int incDec) {
        Query query = new Query();
        query.addCriteria(Criteria.where("barcode").is(tireId)
                .and("accounts").elemMatch(Criteria.where("garageId").is(garageId)));

        Update update = new Update();
        update.inc("accounts.$.count", incDec);
        update.set("accounts.$.updatedTime", System.currentTimeMillis());
        FindAndModifyOptions options = FindAndModifyOptions.options();
        options.returnNew(true);
        return mongoTemplate.findAndModify(query, update, options, Tire.class);
    }


}
