package com.spring.restapi.services.garage;

import com.spring.restapi.models.Garage;
import com.spring.restapi.repositories.GarageRepositoryInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;

@Component
public class GarageService {
    @Autowired
    private GarageRepositoryInterface garageRepository;


    public Iterable<Garage> findAll() {
        List<Garage> list = garageRepository.findAll();
        list.sort(Comparator.comparingLong(Garage::getTimestamp).reversed());
        return list;
    }


    public ResponseEntity save(Garage tire) {
        try {
            tire.setTimestamp(System.currentTimeMillis());
            Garage garage = garageRepository.save(tire);
            if (garage != null) {
                return new ResponseEntity<>(garage, HttpStatus.OK);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.badRequest().build();
    }


    public ResponseEntity show(String email) {
        try {
            System.out.println("Trying get email.. " + email);
            Garage g = garageRepository.findByEmail(email);
            if (g != null) {
                return new ResponseEntity<>(g, HttpStatus.OK);
            } else {
                System.err.println("did find is NULL");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();

    }

    public ResponseEntity update(String id, Garage garage) {
        if (garage != null && id != null) {
            Garage g = garageRepository.findByEmail(id);
            if (g != null) {
                g.setTimestamp(System.currentTimeMillis());
                if (garage.getAddress() != null)
                    g.setAddress(garage.getAddress());
                if (garage.getImageURL() != null)
                    g.setImageURL(garage.getImageURL());
                if (garage.getName() != null)
                    g.setName(garage.getName());
                if (garage.getPhoneNumber() != null)
                    g.setPhoneNumber(garage.getPhoneNumber());
                if (garage.getEmail() != null)
                    g.setEmail(garage.getEmail());
                Garage updated = garageRepository.save(g);
                return new ResponseEntity<>(updated, HttpStatus.OK);
            }
        }
        return ResponseEntity.badRequest().build();
    }


    public ResponseEntity delete(String id) {
        try {
            Garage g = garageRepository.findByEmail(id);
            if (g != null) {
                garageRepository.delete(g);
            }
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }


}
