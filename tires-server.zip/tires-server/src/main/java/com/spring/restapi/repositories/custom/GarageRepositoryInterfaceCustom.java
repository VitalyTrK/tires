package com.spring.restapi.repositories.custom;

public interface GarageRepositoryInterfaceCustom {

}
