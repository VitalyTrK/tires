package com.spring.restapi.repositories.custom;

import com.spring.restapi.models.CustomerRef;
import com.spring.restapi.models.Tire;

import java.util.List;

public interface TireRepositoryInterfaceCustom {

    int addTireToGarage(CustomerRef customerRef, Tire tire);

    List<Tire> getTiresByGarage(String garageId);

    Tire deleteTireFromGarage(String garageId, String tireId);

    Tire setCountByGarage(String garageId, String tireId, int newCount);

    Tire incCountByGarage(String garageId, String tireId ,int newCount);
}
