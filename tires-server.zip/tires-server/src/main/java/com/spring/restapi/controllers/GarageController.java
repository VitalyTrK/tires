/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.restapi.controllers;

import com.spring.restapi.models.Garage;
import com.spring.restapi.services.garage.GarageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @author vitaly .T
 */
@RestController
public class GarageController {

    @Autowired
    private GarageService garageService;

    @RequestMapping(method = RequestMethod.GET, value = "/garage")
    public Iterable<Garage> getAllGarages() {
        return garageService.findAll();
    }

    @RequestMapping(method = RequestMethod.POST, value = "/garage")
    public ResponseEntity saveGarage(@RequestBody Garage tire) {
        return garageService.save(tire);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/garage/{id:.+}")
    public ResponseEntity getGarage(@PathVariable String id) {
        return garageService.show(id);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/garage/{id:.+}")
    public ResponseEntity updateGarage(@PathVariable String id, @RequestBody Garage garage) {
        return garageService.update(id, garage);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/garage/{id:.+}")
    public ResponseEntity deleteGarage(@PathVariable String id) {
        return garageService.delete(id);
    }
}