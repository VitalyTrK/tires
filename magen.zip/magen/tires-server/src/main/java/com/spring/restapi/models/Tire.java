/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.restapi.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;

/**
 * @author didin
 */

@Document(collection = "tires")
public class Tire {

    @Id
    @NotNull
    @Indexed
    private String barcode;
    private String imageURL;
    private String manufacturer;
    private String model;
    private int width;
    private int height;
    private String diameter;
    private int loadIndex;
    private String speedIndex;
    private int price;

    public Tire(String barcode, String imageURL, String manufacturer, String model,
                int width, int height, String diameter, int loadIndex, String speedIndex, int price) {
        this.barcode = barcode;
        this.imageURL = imageURL;
        this.manufacturer = manufacturer;
        this.model = model;
        this.width = width;
        this.height = height;
        this.diameter = diameter;
        this.loadIndex = loadIndex;
        this.speedIndex = speedIndex;
        this.price = price;
    }

    public Tire(){
        super();
    }

    @Override
    public String toString() {
        return "Tire{" +
                "barcode='" + barcode + '\'' +
                ", imageURL='" + imageURL + '\'' +
                ", manufacturer='" + manufacturer + '\'' +
                ", model='" + model + '\'' +
                ", width=" + width +
                ", height=" + height +
                ", diameter='" + diameter + '\'' +
                ", loadIndex=" + loadIndex +
                ", speedIndex='" + speedIndex + '\'' +
                ", price=" + price +
                '}';
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public String getDiameter() {
        return diameter;
    }

    public void setDiameter(String diameter) {
        this.diameter = diameter;
    }

    public int getLoadIndex() {
        return loadIndex;
    }

    public void setLoadIndex(int loadIndex) {
        this.loadIndex = loadIndex;
    }

    public String getSpeedIndex() {
        return speedIndex;
    }

    public void setSpeedIndex(String speedIndex) {
        this.speedIndex = speedIndex;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
