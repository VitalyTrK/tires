package com.spring.restapi.models;

public class CustomerRef {

    public CustomerRef(String garageId, int count) {
        this.garageId = garageId;
        this.count = count;
    }

    public CustomerRef() {
        super();
    }

    private String garageId;
    private int count;

    public String getGarageId() {
        return garageId;
    }

    public void setGarageId(String garageId) {
        this.garageId = garageId;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
