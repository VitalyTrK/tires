/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.restapi.repositories;

import com.spring.restapi.models.Tire;
import com.spring.restapi.repositories.custom.TireRepositoryInterfaceCustom;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

/**
 * @author didin
 */
@Component
public interface TireRepositoryInterface extends CrudRepository<Tire, String>, TireRepositoryInterfaceCustom {


    @Override
    Tire findOne(String id);

    @Override
    void delete(Tire deleted);
}
