package com.spring.restapi.repositories.custom;

import com.spring.restapi.models.CustomerRef;
import com.spring.restapi.models.Tire;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

@Component
public class TireRepositoryInterfaceImpl implements TireRepositoryInterfaceCustom {

    @Autowired
    protected MongoTemplate mongoTemplate;

    @Override
    public int addTireToGarage(CustomerRef customerRef, Tire tire) {
        return mongoTemplate.updateFirst(
                Query.query(Criteria.where("_id").is(tire.getBarcode())),
                new Update().addToSet("account", customerRef), Tire.class).getN();
    }
}
