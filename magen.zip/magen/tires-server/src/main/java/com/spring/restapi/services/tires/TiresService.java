package com.spring.restapi.services.tires;


import com.spring.restapi.models.CustomerRef;
import com.spring.restapi.models.Tire;
import com.spring.restapi.repositories.TireRepositoryInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TiresService {
    @Autowired
    private TireRepositoryInterface tireRepository;


    public int addTire(CustomerRef customerRef, Tire tire) {
        if (tireRepository.findOne(tire.getBarcode()) != null) {
            // already exists..assign to garage
            return tireRepository.addTireToGarage(customerRef, tire);
        } else {
            if (tireRepository.save(tire) != null) {
                return tireRepository.addTireToGarage(customerRef, tire);
            }
        }
        return -1;
    }

}