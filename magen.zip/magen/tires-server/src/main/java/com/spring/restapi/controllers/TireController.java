/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.restapi.controllers;

import com.spring.restapi.models.CustomerRef;
import com.spring.restapi.models.Tire;
import com.spring.restapi.services.tires.TiresService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author vitaly .T
 */
@RestController
public class TireController {

    @Autowired
    TiresService tiresService;
//
//    @RequestMapping(method = RequestMethod.GET, value = "/tires")
//    public Iterable<Tire> product() {
//        return tireRepository.findAll();
//    }

    @RequestMapping(method = RequestMethod.GET, value = "/test")
    public String test() {
        return "hello Tal new API is coming...";
    }

    @RequestMapping(method = RequestMethod.POST, value = "/tires/add/garage/{id}/{count}")
    public int save(@PathVariable String id, @PathVariable String count, @RequestBody Tire tire) {
        CustomerRef customerRef = new CustomerRef(id, Integer.parseInt(count));
        return tiresService.addTire(customerRef, tire);
    }
//
//    @RequestMapping(method = RequestMethod.GET, value = "/tires/{id}")
//    public Tire show(@PathVariable String id) {
//        return tireRepository.findOne(id);
//    }
//
//    @RequestMapping(method = RequestMethod.PUT, value = "/tires/{id}/update")
//    public Tire update(@PathVariable String id, @RequestBody Tire tire) {
//        Tire prod = tireRepository.findOne(id);
//        if (tire.getBarcode() != null)
//            prod.setBarcode(tire.getBarcode());
//        //...TODO complete all fields..
//        tireRepository.save(prod);
//        return prod;
//    }
//
//    @RequestMapping(method = RequestMethod.DELETE, value = "/tires/{id}")
//    public String delete(@PathVariable String id) {
//        Tire product = tireRepository.findOne(id);
//        tireRepository.delete(product);
//
//        return "tire deleted";
//    }
}