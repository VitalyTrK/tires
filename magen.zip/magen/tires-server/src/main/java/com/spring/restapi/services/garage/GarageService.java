package com.spring.restapi.services.garage;

import com.spring.restapi.models.Garage;
import com.spring.restapi.repositories.GarageRepositoryInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class GarageService {
    @Autowired
    GarageRepositoryInterface garageRepository;


    public Iterable<Garage> findAll() {
        return garageRepository.findAll();
    }


    public Garage save(Garage tire) {
        return garageRepository.save(tire);
    }

    public Garage show(String id) {
        return garageRepository.findOne(id);
    }


    public Garage update(String id, Garage garage) {
        Garage prod = garageRepository.findOne(id);
        if (garage.getAddress() != null)
            prod.setAddress(garage.getAddress());
        if (garage.getEmail() != null)
            prod.setEmail(garage.getEmail());
        if (garage.getName() != null)
            prod.setName(garage.getName());
        if (garage.getPhoneNumber() != null)
            prod.setPhoneNumber(garage.getPhoneNumber());
        garageRepository.save(prod);
        return prod;
    }


    public void delete(String id) {
        Garage product = garageRepository.findOne(id);
        garageRepository.delete(product);
    }


}
