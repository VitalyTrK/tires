package com.spring.restapi.repositories.custom;

import com.spring.restapi.models.CustomerRef;
import com.spring.restapi.models.Tire;

public interface TireRepositoryInterfaceCustom {

    int addTireToGarage(CustomerRef customerRef, Tire tire);
}
