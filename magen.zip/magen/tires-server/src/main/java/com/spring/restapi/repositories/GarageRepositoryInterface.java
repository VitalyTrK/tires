/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.restapi.repositories;

import com.spring.restapi.models.Garage;
import com.spring.restapi.repositories.custom.GarageRepositoryInterfaceCustom;
import org.springframework.data.repository.CrudRepository;

/**
 * @author vitalytarasiuk
 */
public interface GarageRepositoryInterface extends CrudRepository<Garage, String>, GarageRepositoryInterfaceCustom {
    @Override
    Garage findOne(String id);

    @Override
    void delete(Garage deleted);
}
