package com.spring.restapi.services;


import com.mongodb.DBObject;
import com.spring.restapi.models.SearchDto;
import com.spring.restapi.models.TireDto;
import com.spring.restapi.models.Wrapper;
import com.spring.restapi.repositories.TireRepositoryInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class SearchService {
    @Autowired
    private TireRepositoryInterface tireRepository;


    public ResponseEntity searchTiresByGarage(String garageId, SearchDto searchDto) {
        try {
            Wrapper tireDtos = tireRepository.searchTiresByGarageAndSearchDto(garageId, searchDto);
            return new ResponseEntity<>(tireDtos, HttpStatus.OK);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
}