/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.restapi.controllers;

import com.spring.restapi.models.SearchDto;
import com.spring.restapi.services.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @author vitaly .T
 */
@RestController
public class SearchController {

    @Autowired
    private SearchService searchService;


    @RequestMapping(method = RequestMethod.POST, value = "/search/{garageId:.+}/tires")
    public ResponseEntity search(@PathVariable String garageId, @RequestBody SearchDto searchDto) {
        return searchService.searchTiresByGarage(garageId, searchDto);
    }


}