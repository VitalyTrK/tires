package com.spring.restapi.services;

import com.spring.restapi.models.Action;
import com.spring.restapi.models.GarageDto;
import com.spring.restapi.repositories.GarageRepositoryInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;

@Component
public class ActionService {


    @Autowired
    private GarageRepositoryInterface garageRepositoryInterface;


    public ResponseEntity<Object> addActionToGarage(String garageId, Action action) {
        try {
            GarageDto garage = garageRepositoryInterface.addActionToGarage(garageId, action);
            if (garage != null) {
                return new ResponseEntity<>(garage, HttpStatus.OK);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity deleteActionsByGarage(String garageId) {
        try {
            if (garageId != null) {
                GarageDto garage = garageRepositoryInterface.findByEmail(garageId);
                if (garage != null && garage.getActionList() != null) {
                    garage.setActionList(new ArrayList<>());
                    GarageDto res = garageRepositoryInterface.save(garage);
                    return new ResponseEntity<>(res, HttpStatus.OK);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity getActionsByGarage(String garageId) {
        try {
            if (garageId != null) {
                GarageDto garage = garageRepositoryInterface.findByEmail(garageId);
                if (garage != null && garage.getActionList() != null) {
                    return new ResponseEntity<>(garage.getActionList().stream().sorted(Comparator.
                            comparing(Action::getUpdateSortTime).reversed()).collect(Collectors.toList()), HttpStatus.OK);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

}
