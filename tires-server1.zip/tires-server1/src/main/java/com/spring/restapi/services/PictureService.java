package com.spring.restapi.services;

import com.spring.restapi.models.PictureDto;
import com.spring.restapi.models.PictureView;
import com.spring.restapi.repositories.PictrureRepositoryInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PictureService {

    @Autowired
    private PictrureRepositoryInterface pictrureRepositoryInterface;


    public ResponseEntity save(PictureDto pictureDto) {
        try {
            PictureDto garage = pictrureRepositoryInterface.save(pictureDto);
            if (garage != null) {
                return new ResponseEntity<>(garage, HttpStatus.OK);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity findAll() {
        try {
            List<PictureDto> all = pictrureRepositoryInterface.findAll();
            if (all != null) {
                return new ResponseEntity<>(new PictureView(all), HttpStatus.OK);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.badRequest().build();
    }
}
