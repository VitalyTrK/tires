package com.spring.restapi.services;

import com.spring.restapi.models.GarageDto;
import com.spring.restapi.models.Worker;
import com.spring.restapi.repositories.GarageRepositoryInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.stream.Collectors;

@Component
public class WorkerService {


    @Autowired
    private GarageRepositoryInterface garageRepositoryInterface;


    public ResponseEntity<Object> addWorkerToGarage(String garageId, Worker worker) {
        try {
            GarageDto garage = garageRepositoryInterface.addWorkerToGarage(garageId, worker);
            if (garage != null) {
                return new ResponseEntity<>(garage, HttpStatus.OK);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity<Object> deleteWorkerFromGarage(String workerId, String garageId) {
        try {
            System.out.println("Trying delete garageId:" + garageId + " workerId:" + workerId);
            GarageDto garage = garageRepositoryInterface.deleteWorkerFromGarage(garageId, workerId);
            if (garage != null) {
                return ResponseEntity.ok().build();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity<GarageDto> getGarageByWorker(String workerId) {
        try {
            GarageDto garage = garageRepositoryInterface.getGarageByWorker(workerId);
            if (garage != null) {
                return new ResponseEntity<>(garage, HttpStatus.OK);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }


    public ResponseEntity getWorkesByGarage(String garageId) {
        try {
            if (garageId != null) {
                GarageDto garage = garageRepositoryInterface.findByEmail(garageId);
                if (garage != null && garage.getWorkerList() != null) {
                    return new ResponseEntity<>(garage.getWorkerList().stream().
                            sorted(Comparator.comparingLong(Worker::getUpdatedTime).reversed()).collect(Collectors.toList()),
                            HttpStatus.OK);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity updateWorkerByGarage(String garageId, String workerId, Worker toUpdate) {
        try {
            if (garageId != null) {
                GarageDto w = garageRepositoryInterface.updateWorkerByGarage(garageId, workerId, toUpdate);
                if (w != null) {
                    return new ResponseEntity<>(w, HttpStatus.OK);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }
}
