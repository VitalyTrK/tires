package com.spring.restapi.services;


import com.spring.restapi.models.CustomerRef;
import com.spring.restapi.models.GarageDto;
import com.spring.restapi.models.MyResponse;
import com.spring.restapi.models.TireDto;
import com.spring.restapi.repositories.GarageRepositoryInterface;
import com.spring.restapi.repositories.TireRepositoryInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class TiresService {
    @Autowired
    private TireRepositoryInterface tireRepository;
    @Autowired
    private GarageRepositoryInterface garageRepositoryInterface;


    public ResponseEntity addTire(CustomerRef customerRef, TireDto tire) {
        try {
            tire.setUpdateTime(System.currentTimeMillis());
            if (garageRepositoryInterface.findByEmail(customerRef.getGarageId()) != null) {

                TireDto tireDto = tireRepository.getTireByGarage(customerRef.getGarageId(), tire.getBarcode());
                if (tireDto != null) {
                    return new ResponseEntity<>(new MyResponse(tireDto.getManufacturer() + "" + tireDto.getModel(),
                            tireDto.getBarcode(), tireDto.getCount(), true), HttpStatus.OK);
                } else {
                    TireDto general = tireRepository.findOne(tire.getBarcode());
                    if (general == null) {
                        //add to general because not exist
                        System.out.println("Not exist is garage and NOT exist generally so adding to General: " + tire.toString());
                        if (tireRepository.save(tire) != null) {
                            //add to garage with count
                            System.out.println("Exist is general and NOT exist in garafe so  adding to Garage: " + tire.toString() + " to garage:" + customerRef.getGarageId());
                            if (tireRepository.addTireToGarage(customerRef, tire) != null) {
                                return new ResponseEntity<>(new MyResponse("",
                                        tire.getBarcode(), 0, false), HttpStatus.OK);
                            }

                        }
                    } else {
                        //exist generally and not in garage , need add to gaarge
                        System.out.println("Not exist is garage but exist generally adding tire: " + tire.toString() + " to garage:" + customerRef.getGarageId());
                        tireRepository.addTireToGarage(customerRef, tire);
                        return new ResponseEntity<>(new MyResponse(general.getManufacturer() + "" + general.getModel(),
                                general.getBarcode(), tire.getCount(), false), HttpStatus.OK);
                    }
                }
            } else {
                System.err.println("GarageDto dont exists..");
                return ResponseEntity.badRequest().build();
            }
            System.err.println("Other1");
            return ResponseEntity.badRequest().build();

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Other2");
            return ResponseEntity.badRequest().build();
        }
    }

    public ResponseEntity getTire(String tireId) {
        try {
            TireDto tire = tireRepository.findOne(tireId);
            if (tire != null) {
                return new ResponseEntity<>(tire, HttpStatus.OK);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity getAllTires() {
        try {
            List<TireDto> all = tireRepository.findAll(new Sort(Sort.DEFAULT_DIRECTION.ASC, "updateTime"));
            if (all != null) {
                return new ResponseEntity<>(all, HttpStatus.OK);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }


    public ResponseEntity setCountByGarage(String garageId, String tireId, int count) {
        GarageDto garage = tireRepository.setCountByGarage(garageId, tireId, count);
        if (garage != null) {
            return new ResponseEntity<>(garage, HttpStatus.OK);
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity incCountByGarage(String garageId, String tireId, int incDec) {
        GarageDto garage = tireRepository.incCountByGarage(garageId, tireId, incDec);
        if (garage != null) {
            return new ResponseEntity<>(garage, HttpStatus.OK);
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity updateTire(String tireId, TireDto tire) {
        try {
            TireDto toUpdate = tireRepository.findOne(tireId);
            if (toUpdate != null) {
                toUpdate.setUpdateTime(System.currentTimeMillis());
                toUpdate.setDiameter(tire.getDiameter());
                toUpdate.setHeight(tire.getHeight());
                toUpdate.setImageURL(tire.getImageURL());
                toUpdate.setLoadIndex(tire.getLoadIndex());
                toUpdate.setManufacturer(tire.getManufacturer());
                toUpdate.setModel(tire.getModel());
                toUpdate.setPrice(tire.getPrice());
                toUpdate.setSpeedIndex(tire.getSpeedIndex());
                toUpdate.setWidth(tire.getWidth());

                TireDto updated = tireRepository.save(toUpdate);
                if (updated != null) {
                    return new ResponseEntity<>(updated, HttpStatus.OK);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity deleteTire(String tireId) {
        try {
            if (tireId != null) {
                tireRepository.delete(tireId);
                return ResponseEntity.ok().build();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }


    public ResponseEntity updateTireByGarage(String garageId, String tireId, TireDto tire) {
        try {
            if (tire != null && garageId != null && tireId != null) {
                MyResponse myResponse = tireRepository.updateTireByGarage(garageId, tireId, tire);
                if (myResponse != null) {
                    return new ResponseEntity<>(myResponse, HttpStatus.OK);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity deleteTireFromGarage(String garageId, String tireId) {
        try {
            if (tireId != null) {
                GarageDto garage = tireRepository.deleteTireFromGarage(garageId, tireId);
                if (garage != null) {
                    return ResponseEntity.ok().build();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }

    public ResponseEntity getTireFromGarage(String garageId, String tireId) {
        try {
            if (tireId != null) {
                List<TireDto> tires = tireRepository.getTiresByGarage(garageId);
                if (tires != null) {
                    Optional<TireDto> t = tires.stream().filter(s -> s.getBarcode() != null &&
                            s.getBarcode().equalsIgnoreCase(tireId)).findFirst();
                    if (t.isPresent()) {
                        return new ResponseEntity<>(t.get(), HttpStatus.OK);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }


    public ResponseEntity getTiresByGarage(String garageId) {
        try {
            if (garageId != null) {
                List<TireDto> tires = tireRepository.getTiresByGarage(garageId);
                if (tires != null) {
                    return new ResponseEntity<>(tires, HttpStatus.OK);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
        return ResponseEntity.badRequest().build();
    }


}