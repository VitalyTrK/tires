package com.spring.restapi.models;

import java.util.List;

public class PictureView {
    public PictureView(List<PictureDto> pictureDtoList) {
        this.result = pictureDtoList;
    }

    private List<PictureDto> result;

    public List<PictureDto> getResult() {
        return result;
    }

    public void setResult(List<PictureDto> result) {
        this.result = result;
    }
}
