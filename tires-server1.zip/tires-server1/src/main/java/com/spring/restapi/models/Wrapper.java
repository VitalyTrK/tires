package com.spring.restapi.models;

import com.mongodb.DBObject;

public class Wrapper {
    private DBObject result;

    public Wrapper(DBObject result) {
        this.result = result;
    }

    public DBObject getResult() {
        return result;
    }

    public void setResult(DBObject result) {
        this.result = result;
    }
}
