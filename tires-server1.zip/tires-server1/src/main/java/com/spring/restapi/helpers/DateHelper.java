package com.spring.restapi.helpers;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class DateHelper {

    private final static Calendar calendar = Calendar.getInstance();
    private final static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss", Locale.ENGLISH);
    public final static DateFormat FMT_IN = new SimpleDateFormat("MMM dd hh:mm:ss yyyy", Locale.ENGLISH);

    public static void main(String[] args) throws ParseException {
        DateFormat FMT_IN2 = new SimpleDateFormat("dd/M/yyyy hh:mm", Locale.ENGLISH);
        long lineTim2e = FMT_IN2.parse(" 02/11/2018 17:03").getTime();
        long lineTime = FMT_IN.parse("Jun  6 04:07:11 2018").getTime();
        System.out.println(lineTime);
    }


    public static String convertMilliSecondsToFormattedDate(long milliSeconds) {
        calendar.setTimeInMillis(milliSeconds);
        return simpleDateFormat.format(calendar.getTime());
    }

}