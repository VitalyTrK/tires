package com.spring.restapi.models;

public class Image {

    public Image() {
    }


    private String bytes;
//    private String name;

    public String getBytes() {
        return bytes;
    }

//    public String getName() {
//        return name;
//    }

//    public void setName(String name) {
//        this.name = name;
//    }

    public void setBytes(String bytes) {
        this.bytes = bytes;
    }
}
