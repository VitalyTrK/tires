/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.restapi.controllers;

import com.spring.restapi.models.Action;
import com.spring.restapi.services.ActionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @author vitaly .T
 */
@RestController
public class ActionController {

    @Autowired
    private ActionService actionService;


    @RequestMapping(method = RequestMethod.DELETE, value = "action/garage/{id:.+}")
    public ResponseEntity deleteActionsByGarage(@PathVariable String id) {
        return actionService.deleteActionsByGarage(id);
    }

    @RequestMapping(method = RequestMethod.POST, value = "action/garage/{id:.+}")
    public ResponseEntity addWorkerToGarage(@PathVariable String id, @RequestBody Action action) {
        return actionService.addActionToGarage(id, action);
    }

    @RequestMapping(method = RequestMethod.GET, value = "action/garage/{id:.+}")
    public ResponseEntity getActionsByGarage(@PathVariable String id) {
        return actionService.getActionsByGarage(id);
    }


}