package com.spring.restapi.models;

public class CustomerRef {

    public CustomerRef(String garageId, int count) {
        this.garageId = garageId;
        this.count = count;
        this.updatedTime = System.currentTimeMillis();
    }

    public CustomerRef() {
        super();
    }

    private String garageId;
    private int count;
    private long updatedTime;

    public long getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(long updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getGarageId() {
        return garageId;
    }

    public void setGarageId(String garageId) {
        this.garageId = garageId;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "CustomerRef{" +
                "garageId='" + garageId + '\'' +
                ", count=" + count +
                ", updatedTime=" + updatedTime +
                '}';
    }
}
