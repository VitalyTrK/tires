package com.spring.restapi.models;

import java.net.URL;

public class ImageView {
    private URL url;

    public ImageView(URL url) {
        this.url = url;
    }

    public URL getUrl() {
        return url;
    }

    public void setUrl(URL url) {
        this.url = url;
    }
}
