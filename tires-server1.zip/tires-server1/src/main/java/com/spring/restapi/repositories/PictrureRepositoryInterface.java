/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.restapi.repositories;

import com.spring.restapi.models.PictureDto;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * @author vitalytarasiuk
 */
public interface PictrureRepositoryInterface extends MongoRepository<PictureDto, String> {
    @Override
    PictureDto findOne(String id);


//    @Query(value = "{'userId' : ?0, 'groupId' : ?1}", count = true)
//    Long countByUserAndGroup(String userId, String groupId);
}
