package com.spring.restapi.models;

public class MyResponse {
    public MyResponse(String status) {
        this.status = status;
    }

    public MyResponse(String display, String barcode, int count, boolean exist) {
        this.display = display;
        this.barcode = barcode;
        this.count = count;
        this.exist = exist;
    }

    private String display;
    private String barcode;
    private int count;
    private String status;
    private boolean exist;

    public String getDisplay() {
        return display;
    }

    public void setDisplay(String display) {
        this.display = display;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getStatus() {
        return status;
    }

    public boolean isExist() {
        return exist;
    }

    public void setExist(boolean exist) {
        this.exist = exist;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
