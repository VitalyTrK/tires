package com.spring.restapi.repositories.custom;

public interface WorkerRepositoryInterfaceCustom {


}
