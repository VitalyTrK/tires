package com.spring.restapi.repositories.custom;

import com.spring.restapi.models.Action;
import com.spring.restapi.models.GarageDto;
import com.spring.restapi.models.Worker;

import java.util.List;

public interface GarageRepositoryInterfaceCustom {

    GarageDto addWorkerToGarage(String garageId, Worker worker);

    GarageDto updateWorkerByGarage(String garageId, String workerId, Worker toUpdate);

    GarageDto deleteWorkerFromGarage(String garageId, String workerId);

    GarageDto getGarageByWorker(String workerId);

    GarageDto addActionToGarage(String garageId, Action action);

    int addActionsToGarage(String garageId, List<Action> actions);


}
