/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.restapi.controllers;

import com.spring.restapi.models.Image;
import com.spring.restapi.models.PictureDto;
import com.spring.restapi.services.PictureService;
import com.spring.restapi.storage.S3Storage;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author vitaly .T
 */
@RestController
public class ContentController {


    @Autowired
    private S3Storage s3Storage;

    @Autowired
    private PictureService pictureService;


    @RequestMapping(method = RequestMethod.POST, value = "image", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity uploadGarageFile(@RequestBody Image image) {
        long s = System.currentTimeMillis();
        byte[] dec = Base64.decodeBase64(image.getBytes());
        System.out.println(" took decode " + (System.currentTimeMillis() - s));
        return s3Storage.uploadFile("pic" + s, dec);
    }


    @RequestMapping(method = RequestMethod.POST, value = "picture", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity uploadPictures(@RequestBody PictureDto galaryDto) {
        return pictureService.save(galaryDto);
    }

    @RequestMapping(method = RequestMethod.GET, value = "pictures")
    @Cacheable("pictures")
    public ResponseEntity getAllPictures() {
        return pictureService.findAll();
    }


//    @RequestMapping(method = RequestMethod.POST, value = "image", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
//            produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity uploadImage(@RequestParam("image") String image) {
//        byte byteArray[] = Base64.decodeBase64(image);
//        return s3Storage.uploadFile("pic" + System.currentTimeMillis(), byteArray);
//    }


}