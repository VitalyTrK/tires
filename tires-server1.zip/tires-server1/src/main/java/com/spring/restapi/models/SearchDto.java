package com.spring.restapi.models;

public class SearchDto {
    private int width;
    private int height;
    private String diameter;
    private String brand;
    private String tireType;


    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public String getDiameter() {
        return diameter;
    }

    public void setDiameter(String diameter) {
        this.diameter = diameter;
    }

    public String isBrand() {
        return brand;
    }

    public String getTireType() {
        return tireType;
    }

    public void setTireType(String tireType) {
        this.tireType = tireType;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }
}
