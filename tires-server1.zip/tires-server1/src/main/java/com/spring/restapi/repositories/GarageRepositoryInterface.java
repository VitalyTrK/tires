/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.restapi.repositories;

import com.spring.restapi.models.GarageDto;
import com.spring.restapi.repositories.custom.GarageRepositoryInterfaceCustom;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

/**
 * @author vitalytarasiuk
 */
public interface GarageRepositoryInterface extends MongoRepository<GarageDto, String>, GarageRepositoryInterfaceCustom {
    @Override
    GarageDto findOne(String id);

    @Query("{'email' : ?0 }")
    GarageDto findByEmail(String email);

    @Override
    void delete(GarageDto deleted);

//    @Query(value = "{'userId' : ?0, 'groupId' : ?1}", count = true)
//    Long countByUserAndGroup(String userId, String groupId);
}
