package com.spring.restapi.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.IndexDirection;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;


@Document(collection = "garages")
public class GarageDto {
    public GarageDto() {
        super();
    }

    @Id
    @NotNull
    @Indexed
    private String id;
    @Indexed
    private String address;
    @Indexed
    private String phoneNumber;
    @Indexed
    private String name;
    @Indexed
    private String image;
    @Indexed
    private boolean isMessagesEnable;
    @Indexed
    private boolean isManageWorkers;

    @Indexed(direction = IndexDirection.DESCENDING)
    private List<Worker> workerList = new ArrayList<>();
    @Indexed(direction = IndexDirection.DESCENDING)
    private List<Action> actionList = new ArrayList<>();
    @Indexed(direction = IndexDirection.DESCENDING)
    private List<TireDto> tireList = new ArrayList<>();

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @NotNull
    @Indexed(name = "timestamp", direction = IndexDirection.DESCENDING)
    private long timestamp;
    @NotNull
    @Indexed(name = "email", direction = IndexDirection.DESCENDING, unique = true)
    private String email;
    @Indexed
    private String imageURL;


    public List<TireDto> getTireList() {
        return tireList;
    }

    public void setTireList(List<TireDto> tireList) {
        this.tireList = tireList;
    }

    public List<Worker> getWorkerList() {
        return workerList;
    }

    public List<Action> getActionList() {
        return actionList;
    }

    public void setActionList(List<Action> actionList) {
        this.actionList = actionList;
    }

    public void setWorkerList(List<Worker> workerList) {
        this.workerList = workerList;
    }

    public boolean isMessagesEnable() {
        return isMessagesEnable;
    }

    public void setMessagesEnable(boolean messagesEnable) {
        isMessagesEnable = messagesEnable;
    }

    public boolean isManageWorkers() {
        return isManageWorkers;
    }

    public void setManageWorkers(boolean manageWorkers) {
        isManageWorkers = manageWorkers;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getAddress() {
        return address;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "GarageDto{" +
                "id='" + id + '\'' +
                ", address='" + address + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", name='" + name + '\'' +
                ", isMessagesEnable=" + isMessagesEnable +
                ", isManageWorkers=" + isManageWorkers +
                ", workerList=" + workerList +
                ", actionList=" + actionList +
                ", tireList=" + tireList +
                ", timestamp=" + timestamp +
                ", email='" + email + '\'' +
                ", imageURL='" + imageURL + '\'' +
                '}';
    }
}
