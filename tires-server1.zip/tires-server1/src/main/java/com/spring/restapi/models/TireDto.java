/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.restapi.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @author didin
 */
@Document(collection = "tires")
public class TireDto {

    @Id
    @NotNull
    @Indexed
    private String barcode;
    @Indexed
    private String imageURL;
    private String manufacturer;
    @Indexed
    private String model;
    @Indexed
    private int width;
    @Indexed
    private int height;
    @Indexed
    private String diameter;
    private int loadIndex;
    @Indexed
    private String speedIndex;
    private int price;
    @Indexed
    private int count;
    @Indexed
    private String brand;
    @Indexed
    private String important;
    @Indexed
    private String country;
    @Indexed
    private String origin;
    private List<CustomerRef> accounts;
    @Indexed
    private String tireType;
    private long updateTime;

    public String getTireType() {
        return tireType;
    }

    public String isBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String isImportant() {
        return important;
    }

    public void setImportant(String important) {
        this.important = important;
    }

    public void setTireType(String tireType) {
        this.tireType = tireType;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public TireDto() {
        super();
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public List<CustomerRef> getAccounts() {
        return accounts;
    }

    public void setAccounts(List<CustomerRef> accounts) {
        this.accounts = accounts;
    }

    @Override
    public String toString() {
        return "TireDto{" +
                "barcode='" + barcode + '\'' +
                ", imageURL='" + imageURL + '\'' +
                ", manufacturer='" + manufacturer + '\'' +
                ", model='" + model + '\'' +
                ", width=" + width +
                ", height=" + height +
                ", diameter='" + diameter + '\'' +
                ", loadIndex=" + loadIndex +
                ", speedIndex='" + speedIndex + '\'' +
                ", price=" + price +
                '}';
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public String getDiameter() {
        return diameter;
    }

    public void setDiameter(String diameter) {
        this.diameter = diameter;
    }

    public int getLoadIndex() {
        return loadIndex;
    }

    public void setLoadIndex(int loadIndex) {
        this.loadIndex = loadIndex;
    }

    public String getSpeedIndex() {
        return speedIndex;
    }

    public String getBrand() {
        return brand;
    }

    public String getImportant() {
        return important;
    }

    public void setSpeedIndex(String speedIndex) {
        this.speedIndex = speedIndex;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
