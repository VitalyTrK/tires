package com.spring.restapi.repositories.custom;

import com.spring.restapi.helpers.DateHelper;
import com.spring.restapi.models.Action;
import com.spring.restapi.models.GarageDto;
import com.spring.restapi.models.Worker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class GarageRepositoryInterfaceImpl implements GarageRepositoryInterfaceCustom {

    @Autowired
    protected MongoTemplate mongoTemplate;


    @Override
    public GarageDto addWorkerToGarage(String garageId, Worker worker) {
        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(garageId));
        GarageDto g = mongoTemplate.findOne(query, GarageDto.class);
        List<Worker> workers = g.getWorkerList();
        if (workers == null) {
            workers = new ArrayList<>();
        }
        worker.setUpdatedTime(System.currentTimeMillis());
        workers.add(worker);
        g.setWorkerList(workers);
        try {
            mongoTemplate.save(g);
            return g;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public GarageDto getGarageByWorker(String workerId) {
        List<GarageDto> garages = mongoTemplate.findAll(GarageDto.class);
        for (GarageDto g : garages) {
            if (g.getWorkerList() != null) {
                for (Worker w : g.getWorkerList()) {
                    if (w != null && w.getEmail() != null && w.getEmail().equalsIgnoreCase(workerId)) {
                        return g;
                    }
                }
            }
        }
        return null;
    }

    @Override
    public GarageDto deleteWorkerFromGarage(String garageId, String workerId) {
        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(garageId)
                .and("workerList").elemMatch(Criteria.where("email").is(workerId)));

        Update update = new Update();
        update.pull("workerList", new Query().addCriteria(Criteria.where("email").is(workerId)));
        FindAndModifyOptions options = FindAndModifyOptions.options();
        options.returnNew(true);
        return mongoTemplate.findAndModify(query, update, options, GarageDto.class);
    }

    @Override
    public GarageDto addActionToGarage(String garageId, Action action) {
        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(garageId));
        GarageDto g = mongoTemplate.findOne(query, GarageDto.class);
        List<Action> actions = g.getActionList();
        if (actions == null) {
            actions = new ArrayList<>();
        }
        action.setUpdatedTime(DateHelper.convertMilliSecondsToFormattedDate(System.currentTimeMillis()));
        action.setUpdateSortTime(System.currentTimeMillis());
        actions.add(action);
        g.setActionList(actions);
        try {
            mongoTemplate.save(g);
            return g;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public int addActionsToGarage(String garageId, List<Action> actions) {
        //TODO
        return 0;
    }

    @Override
    public GarageDto updateWorkerByGarage(String garageId, String workerId, Worker toUpdate) {
        //TODO find and modify
        Query query = new Query();
        try {
            query.addCriteria(Criteria.where("email").is(garageId));
            GarageDto garage = mongoTemplate.findOne(query, GarageDto.class);

            List<Worker> workers = garage.getWorkerList();
            System.out.println("workser size: " + workers.size());
            for (Worker w : workers) {
                // need phone number and email
                if ((w != null && (w.getEmail() != null && workerId != null && workerId.equalsIgnoreCase(w.getEmail())))) {
                    if (toUpdate.getAddress() != null) {
                        w.setAddress(toUpdate.getAddress());
                    }
                    if (toUpdate.getEmail() != null) {
                        w.setEmail(toUpdate.getEmail());
                    }
                    if (toUpdate.getFirstName() != null) {
                        w.setFirstName(toUpdate.getFirstName());
                    }
                    if (toUpdate.getLastName() != null) {
                        w.setLastName(toUpdate.getLastName());
                    }
                    if (toUpdate.getPhoneNumber() != null) {
                        w.setPhoneNumber(toUpdate.getPhoneNumber());
                    }

                    w.setUpdatedTime(System.currentTimeMillis());
                }
            }
            garage.setWorkerList(workers);
            mongoTemplate.save(garage);

            return garage;
        } catch (Exception e) {
            return null;
        }
    }


}
