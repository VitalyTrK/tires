//package com.spring.restapi.services;
//
//import com.spring.restapi.storage.S3Storage;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import java.io.ByteArrayInputStream;
//import java.io.InputStream;
//
//public class ContentService {
//    @Autowired
//    private S3Storage s3Storage;
//
//    public void uploudFile(byte[] bI){
//        InputStream fis = new ByteArrayInputStream(bI);
//
//
//
//    }
//}
