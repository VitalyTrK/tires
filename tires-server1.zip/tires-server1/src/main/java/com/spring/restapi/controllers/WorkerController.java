/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.restapi.controllers;

import com.spring.restapi.models.Worker;
import com.spring.restapi.services.WorkerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @author vitaly .T
 */
@RestController
public class WorkerController {

    @Autowired
    private WorkerService workerService;

//    @RequestMapping(method = RequestMethod.GET, value = "/worker")
//    public Iterable<GarageDto> getAllGarages() {
//        return workerService.findAll();
//    }

    @RequestMapping(method = RequestMethod.POST, value = "worker/garage/{id:.+}")
    public ResponseEntity addWorkerToGarage(@PathVariable String id, @RequestBody Worker worker) {
        return workerService.addWorkerToGarage(id, worker);
    }


    @RequestMapping(method = RequestMethod.GET, value = "worker/garage/{id:.+}")
    public ResponseEntity getWorkersByGarage(@PathVariable String id) {
        return workerService.getWorkesByGarage(id);
    }


    @RequestMapping(method = RequestMethod.POST, value = "worker/{workerId:.+}/garage/{id:.+}/update")
    public ResponseEntity updateWorkerByGarage(@PathVariable String id, @PathVariable String workerId, @RequestBody Worker toUpdate) {
        return workerService.updateWorkerByGarage(id, workerId, toUpdate);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "worker/{workerId:.+}/garage/{garageId:.+}")
    public ResponseEntity deleteWorkerFromGarage(@PathVariable String workerId, @PathVariable String garageId) {
        return workerService.deleteWorkerFromGarage(workerId, garageId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "worker/{workerId:.+}/garage")
    public ResponseEntity getGarageByGarage(@PathVariable String workerId) {
        return workerService.getGarageByWorker(workerId);
    }

//
//    @RequestMapping(method = RequestMethod.GET, value = "/garage/{id:.+}")
//    public ResponseEntity getGarage(@PathVariable String id) {
//        return garageService.show(id);
//    }
//
//    @RequestMapping(method = RequestMethod.POST, value = "/garage/{id:.+}")
//    public ResponseEntity updateGarage(@PathVariable String id, @RequestBody GarageDto garage) {
//        return garageService.update(id, garage);
//    }
//
//    @RequestMapping(method = RequestMethod.DELETE, value = "/garage/{id:.+}")
//    public ResponseEntity deleteGarage(@PathVariable String id) {
//        return garageService.delete(id);
//    }
}