package com.spring.restapi.storage;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.google.gson.Gson;
import com.spring.restapi.models.ImageView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.URL;

@Component
public class S3Storage {

    @Autowired
    private String awsS3ImagesBucket;

    private AmazonS3 amazonS3;

    private final static Gson gson = new Gson();

    public S3Storage(@Autowired Region awsRegion, @Autowired AWSCredentialsProvider awsCredentialsProvider) {
        this.amazonS3 = AmazonS3ClientBuilder.standard().withCredentials(awsCredentialsProvider)
                .withRegion(awsRegion.getName()).build();
    }


    public ResponseEntity uploadFile(String filename, byte[] buffer) {
        try {

//            File imgPath = new File("/Users/vitalytarasiuk/Desktop/TireDto.jpeg");
//            BufferedImage bufferedImage = ImageIO.read(imgPath);
//
//            // get DataBufferBytes from Raster
////            WritableRaster raster = bufferedImage .getRaster();
////            DataBufferByte data   = (DataBufferByte) raster.getDataBuffer();
//            ByteArrayOutputStream os = new ByteArrayOutputStream();
//            ImageIO.write(bufferedImage, "png", os);
//
//
//            byte[] buffer = os.toByteArray();

//            System.out.println("Got picture : " + filename);

            String fullFilename = "images/" + filename + "_" + System.currentTimeMillis();
            InputStream fis = new ByteArrayInputStream(buffer);
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentLength(buffer.length);
            metadata.setContentType("image/png");
            metadata.setCacheControl("public, max-age=31536000");

            long sss = System.currentTimeMillis();
            PutObjectRequest putObjectRequest = new PutObjectRequest(this.awsS3ImagesBucket, fullFilename, fis, metadata).
                    withCannedAcl(CannedAccessControlList.PublicRead);
            PutObjectResult putObjectResult = amazonS3.putObject(putObjectRequest);
            if (putObjectResult != null) {
                URL url = amazonS3.getUrl(this.awsS3ImagesBucket, fullFilename);
                if (url != null) {
                    String res = gson.toJson(new ImageView(url));
                    System.out.println("image:" + url + " took store s3" + (System.currentTimeMillis() - sss));
                    return new ResponseEntity<>(res,
                            HttpStatus.OK);
                }
            }
        } catch (AmazonServiceException e) {
            System.err.println(e.getErrorMessage());
        }
        return ResponseEntity.badRequest().build();
    }

    public AmazonS3 getAmazonS3() {
        return amazonS3;
    }
}