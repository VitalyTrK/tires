package com.spring.restapi.models;

import com.spring.restapi.helpers.DateHelper;
import org.springframework.data.mongodb.core.index.IndexDirection;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;

@Document(collection = "actions_log")
public class Action {

    @NotNull
    @Indexed(direction = IndexDirection.DESCENDING)
    private String workerName;
    private String actionTireDisplayName;
    private int actionType;
    private int count;
    private String imageURL;


    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    @Indexed(direction = IndexDirection.DESCENDING)
    private transient long updateSortTime;

    @Indexed(direction = IndexDirection.DESCENDING)
    private String updatedTime;

    public Action(int actionType) {
        this.actionType = actionType;
        this.updatedTime = DateHelper.convertMilliSecondsToFormattedDate(System.currentTimeMillis());
    }

    public Action() {
        super();
    }

    public long getUpdateSortTime() {
        return updateSortTime;
    }

    public void setUpdateSortTime(long updateSortTime) {
        this.updateSortTime = updateSortTime;
    }

    public String getWorkerName() {
        return workerName;
    }

    public void setWorkerName(String workerName) {
        this.workerName = workerName;
    }

    public String getActionTireDisplayName() {
        return actionTireDisplayName;
    }

    public void setActionTireDisplayName(String actionTireDisplayName) {
        this.actionTireDisplayName = actionTireDisplayName;
    }

    public int getActionType() {
        return actionType;
    }

    public void setActionType(int actionType) {
        this.actionType = actionType;
    }

    public String getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(String updatedTime) {
        this.updatedTime = updatedTime;
    }
}
