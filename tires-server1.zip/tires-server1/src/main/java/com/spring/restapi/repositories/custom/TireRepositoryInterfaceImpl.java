package com.spring.restapi.repositories.custom;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.spring.restapi.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregationOptions;

@Component
public class TireRepositoryInterfaceImpl implements TireRepositoryInterfaceCustom {

    @Autowired
    protected MongoTemplate mongoTemplate;

    @Override
    public GarageDto addTireToGarage(CustomerRef customerRef, TireDto tire) {
        System.out.println("trying update addTireToGarage....");
//        System.out.println("trying update addTireToGarage....");
//        // trying to find , if garage ID not exist in array need addToSet ,
//        // if exists just inc count
//        Query query = new Query();
//        query.addCriteria(Criteria.where("email").is(customerRef.getGarageId()));
//        int res =  mongoTemplate.updateFirst(query,
//                new Update().addToSet("tireList", tire), TireDto.class).getN();
//        if(res>0){
//
//        }else{
//
//        }
        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(customerRef.getGarageId()));
        tire.setCount(customerRef.getCount());
        Update update = new Update().addToSet("tireList", tire);
        FindAndModifyOptions options = FindAndModifyOptions.options();
        options.returnNew(true);
        return mongoTemplate.findAndModify(query, update, options, GarageDto.class);
    }

//    @Override
//    public GarageDto addTireToGarage(CustomerRef customerRef, TireDto tire) {
//        System.out.println("trying update addTireToGarage....");
//        Query query = new Query();
//        query.addCriteria(Criteria.where("email").is(customerRef.getGarageId()));
//        GarageDto g = mongoTemplate.findOne(query, GarageDto.class);
//        List<TireDto> tires = g.getTireList();
//        if (tires == null) {
//            tires = new ArrayList<>();
//        }
//        tires.add(tire);
//        g.setTireList(tires);
//        try {
//            mongoTemplate.save(g);
//            return g;
//        } catch (Exception e) {
//            return null;
//        }
//    }


//    @Override
//    public List<TireDto> searchTiresByGarageAndSearchDto(String garageId, SearchDto searchDto) {
//        //try this
////        Query query = new Query();
////        query.addCriteria(Criteria.where("id").is(new ObjectId("58e8da206ca4f710bab6ef74")));
////        query.fields().include("name").elemMatch("courses", Criteria.where("_id").is(new ObjectId("58d65541495c851c1703c57f") ) );
////        List<Course> Course = mongoTemplate.find(query, Course.class);
//        Query query = new Query();
//
//        Criteria where = Criteria.where("email").is(garageId);
//
//        List<Criteria> all = new ArrayList<>();
//        if (searchDto.getDiameter() != null) {
//            all.add(Criteria.where("tireList").elemMatch(Criteria.where("diameter").is(searchDto.getDiameter())));
//        }
//        if (searchDto.getHeight() > 0) {
//            all.add(Criteria.where("tireList").elemMatch(Criteria.where("height").is(searchDto.getHeight())));
//        }
//        if (searchDto.getWidth() > 0) {
//            all.add(Criteria.where("tireList").elemMatch(Criteria.where("width").is(searchDto.getWidth())));
//        }
//        if (searchDto.isBrand() != null) {
//            boolean brand = Boolean.getBoolean(searchDto.isBrand());
//            all.add(Criteria.where("tireList").elemMatch(Criteria.where("brand").is(brand)));
//        }
//        query.addCriteria(where.andOperator(all.toArray(new Criteria[all.size()])));
//
////        List<TireDto> tireDtos = mongoTemplate.find(query, TireDto.class);
//
//        GarageDto garageDto = mongoTemplate.findOne(query, GarageDto.class);
//
//        if (garageDto != null) {
//            return garageDto.getTireList();
//        }
//        return null;
//    }


    public Wrapper searchTiresByGarageAndSearchDto(String garageId, SearchDto searchDto) {
//        Criteria where = Criteria.where("email").is(garageId);
//        if (searchDto.getDiameter() != null) {
//            where.and("tireList.diameter").is(searchDto.getDiameter());
//        }
//        if (searchDto.getHeight() > 0) {
//            where.and("tireList.height").is(searchDto.getHeight());
//        }
//        if (searchDto.getWidth() > 0) {
//            where.and("tireList.width").is(searchDto.getHeight());
//        }
//        if (searchDto.isBrand() != null) {
//            boolean brand = Boolean.getBoolean(searchDto.isBrand());
//            where.and("tireList.brand").is(brand);
//        }
//
//        Aggregation aggregation = Aggregation.newAggregation(
//                Aggregation.match(where),
//                Aggregation.unwind("tireList"),
//                Aggregation.match(where),
//                Aggregation.replaceRoot("tireList")
//        ).withOptions(newAggregationOptions().cursor(new BasicDBObject()).build());
//
//        System.out.println(aggregation.toString());
//
//
////                Aggregation.project(Fields.from(Fields.field("width", "tireList.width"), Fields.field("height", "tireList.height"),
////                        Fields.field("diameter", "tireList.diameter"), Fields.field("brand", "tireList.brand")))).
//        DBObject tireDtos = mongoTemplate.aggregate(aggregation, "garages", TireDto.class).getRawResults();

        Criteria where = Criteria.where("email").is(garageId);
        if (searchDto.getDiameter() != null) {
            where.and("list.diameter").is(searchDto.getDiameter());
        }
        if (searchDto.getHeight() > 0) {
            where.and("tireList.height").is(searchDto.getHeight());
        }
        if (searchDto.getWidth() > 0) {
            where.and("tireList.width").is(searchDto.getWidth());
        }
        if (searchDto.isBrand() != null) {
            boolean brand = Boolean.getBoolean(searchDto.isBrand());
            where.and("tireList.brand").is(brand);
        }
        if (searchDto.getTireType() != null) {
            where.and("tireList.tireType").is(searchDto.getTireType());
        }

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(where),
                Aggregation.unwind("tireList"),
                Aggregation.match(where),
                Aggregation.replaceRoot("tireList")
        ).withOptions(newAggregationOptions().cursor(new BasicDBObject()).build());

        System.out.println(aggregation.toString());

        DBObject tireDtos = mongoTemplate.aggregate(aggregation, "garages", TireDto.class).getRawResults();
        DBObject obj1 = (DBObject) tireDtos.toMap().get("cursor");
        DBObject obj2 = (DBObject) obj1.toMap().get("firstBatch");

//        Type listType = new TypeToken<ArrayList<TireDto>>(){}.getType();
//        List<TireDto> yourClassList = new Gson().fromJson(new Gson().toJson(obj2), listType);
        return new Wrapper(obj2);

    }


    @Override
    public List<TireDto> getTiresByGarage(String garageId) {
        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(garageId));
        GarageDto g = mongoTemplate.findOne(query, GarageDto.class);
        if (g != null) {
            List<TireDto> tires = g.getTireList();
            if (tires != null) {
                return tires.stream().sorted(Comparator.comparingLong(TireDto::getCount).reversed().
                        thenComparing(Comparator.comparingLong(TireDto::getUpdateTime).reversed())).collect(Collectors.toList());
            }

        }
        return null;
    }

    /**
     * TODO see
     * https://www.programcreek.com/java-api-examples/index.php?api=org.springframework.data.mongodb.core.query.Criteria
     *
     * @param garageId
     * @param tireId
     * @param toUpdate
     * @return
     */
    @Override
    public MyResponse updateTireByGarage(String garageId, String tireId, TireDto toUpdate) {
        Query query = new Query();
        try {
            query.addCriteria(Criteria.where("email").is(garageId));
            GarageDto garage = mongoTemplate.findOne(query, GarageDto.class);
            List<TireDto> tires = garage.getTireList();
            System.out.println("tires size: " + tires.size());
            for (TireDto w : tires) {
                // need phone number and email
                if ((w != null && (w.getBarcode() != null && tireId != null
                        && w.getBarcode().equalsIgnoreCase(tireId)))) {

                    System.out.println("Update tire..." + tireId);
                    if (toUpdate.getCount() > 0) {
                        w.setCount(toUpdate.getCount());
                    }
                    if (toUpdate.getDiameter() != null) {
                        w.setDiameter(toUpdate.getDiameter());
                    }
                    if (toUpdate.getHeight() > 0) {
                        w.setHeight(toUpdate.getHeight());
                    }
                    if (toUpdate.getImageURL() != null) {
                        w.setImageURL(toUpdate.getImageURL());
                    }
                    if (toUpdate.getLoadIndex() > 0) {
                        w.setLoadIndex(toUpdate.getLoadIndex());
                    }
                    if (toUpdate.getModel() != null) {
                        w.setModel(toUpdate.getModel());
                    }

                    if (toUpdate.getManufacturer() != null) {
                        w.setManufacturer(toUpdate.getManufacturer());
                    }
                    if (toUpdate.getTireType() != null) {
                        w.setTireType(toUpdate.getTireType());
                    }

                    if (toUpdate.getPrice() > 0) {
                        w.setPrice(toUpdate.getPrice());
                    }

                    if (toUpdate.getSpeedIndex() != null) {
                        w.setSpeedIndex(toUpdate.getSpeedIndex());
                    }

                    if (toUpdate.getWidth() > 0) {
                        w.setWidth(toUpdate.getWidth());
                    }

                    if (toUpdate.isBrand() != null) {
                        w.setBrand(toUpdate.isBrand());
                    }

                    if (toUpdate.isImportant() != null) {
                        w.setImportant(toUpdate.isImportant());
                    }

                    if (toUpdate.getOrigin() != null) {
                        w.setOrigin(toUpdate.getOrigin());
                    }

                    if (toUpdate.getCountry() != null) {
                        w.setCountry(toUpdate.getCountry());
                    }


                    w.setUpdateTime(System.currentTimeMillis());
                }
            }
            garage.setTireList(tires.stream().sorted(Comparator.comparingLong(TireDto::getCount).reversed().
                    thenComparing(Comparator.comparingLong(TireDto::getUpdateTime).reversed())).collect(Collectors.toList()));
            mongoTemplate.save(garage);
            return new MyResponse("OK");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    @Override
    public GarageDto deleteTireFromGarage(String garageId, String tireId) {
        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(garageId));
        GarageDto garage = mongoTemplate.findOne(query, GarageDto.class);
        if (garage != null) {
            List<TireDto> tires = garage.getTireList();
            if (tires != null) {
                IntStream.range(0, tires.size())
                        .filter(i -> tires.get(i).getBarcode().equalsIgnoreCase(tireId))
                        .boxed()
                        .findFirst()
                        .map(i -> tires.remove((int) i));
                garage.setTireList(tires.stream().sorted(Comparator.comparingLong(TireDto::getCount).reversed().
                        thenComparing(Comparator.comparingLong(TireDto::getUpdateTime).reversed())).collect(Collectors.toList()));
                System.out.println(" garage remove:" + garage.getTireList());
                mongoTemplate.save(garage);
                return garage;
            }
        }
        return null;
    }

    @Override
    public TireDto getTireByGarage(String garageId, String tireId) {
        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(garageId)
                .and("tireList").elemMatch(Criteria.where("barcode").is(tireId)));
        GarageDto garageDto = mongoTemplate.findOne(query, GarageDto.class);
        if (garageDto != null) {
            Optional<TireDto> tireDto = garageDto.getTireList().stream().filter(a -> a.getBarcode().equalsIgnoreCase(tireId)).findFirst();
            if (tireDto.isPresent()) {
                return tireDto.get();
            }
        }
        return null;
    }

    @Override
    public GarageDto setCountByGarage(String garageId, String tireId, int newCount) {
        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(garageId)
                .and("tireList").elemMatch(Criteria.where("barcode").is(tireId)));

        Update update = new Update();
        if (newCount >= 0) {
            update.set("tireList.$.count", newCount);
        }
        update.set("tireList.$.updatedTime", System.currentTimeMillis());
        FindAndModifyOptions options = FindAndModifyOptions.options();
        options.returnNew(true);
        return mongoTemplate.findAndModify(query, update, options, GarageDto.class);
    }

//    @Override
//    public GarageDto setCountByGarage(String garageId, String tireId, int newCount) {
//        Query query = new Query();
//        query.addCriteria(Criteria.where("email").is(garageId));
//        GarageDto garage = mongoTemplate.findOne(query, GarageDto.class);
//        if (garage != null) {
//            List<TireDto> tires = garage.getTireList();
//            for (TireDto tire : tires) {
//                if (tire != null) {
//                    if (tire.getBarcode().equalsIgnoreCase(tireId)) {
//                        tire.setCount(newCount);
//                        break;
//                    }
//                }
//            }
//            garage.setTireList(tires);
//            mongoTemplate.save(garage);
//            return garage;
//        }
//        return null;
//    }

    @Override
    public GarageDto incCountByGarage(String garageId, String tireId, int incDec) {
        Query query = new Query();
        query.addCriteria(Criteria.where("email").is(garageId));
        GarageDto garage = mongoTemplate.findOne(query, GarageDto.class);
        if (garage != null) {
            List<TireDto> tires = garage.getTireList();
            for (TireDto tire : tires) {
                if (tire != null) {
                    if (tire.getBarcode().equalsIgnoreCase(tireId)) {
                        tire.setCount(tire.getCount() + incDec);
                        break;
                    }
                }
            }
            garage.setTireList(tires);
            mongoTemplate.save(garage);
            return garage;
        }
        return null;
    }


}
