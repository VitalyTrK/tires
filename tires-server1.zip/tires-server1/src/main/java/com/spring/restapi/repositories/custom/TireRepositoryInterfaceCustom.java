package com.spring.restapi.repositories.custom;

import com.spring.restapi.models.*;

import java.util.List;

public interface TireRepositoryInterfaceCustom {

    TireDto getTireByGarage(String garageId, String tireId);

    GarageDto addTireToGarage(CustomerRef customerRef, TireDto tire);

    List<TireDto> getTiresByGarage(String garageId);

    Wrapper searchTiresByGarageAndSearchDto(String garageId, SearchDto searchDto);

    GarageDto deleteTireFromGarage(String garageId, String tireId);

    MyResponse updateTireByGarage(String garageId, String tireId, TireDto toUpdate);

    GarageDto setCountByGarage(String garageId, String tireId, int newCount);

    GarageDto incCountByGarage(String garageId, String tireId, int newCount);
}
